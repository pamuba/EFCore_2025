﻿using EFCoreDemo_Model.Models;
using EFCroeDemo_DataAccess.Data;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreDemo_Web.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _db;

        public CategoryController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<Categories> objList = _db.Categories.ToList();
            return View(objList);
        }
        public IActionResult Upsert(int? id) {
            Categories category = new();
            if (id == null || id == 0) { 
                //create request
                return View(category);
            }
            //edit
            category = _db.Categories.FirstOrDefault(u=>u.CategoryId == id);
            if(category == null)
            {
                return NotFound();
            }
            return View(category);
           
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upsert(Categories obj)
        {
            if(ModelState.IsValid)
            {
                if (obj.CategoryId == 0)
                {
                    //create
                    await _db.Categories.AddAsync(obj);
                }
                else
                {
                    //update
                    _db.Categories.Update(obj);
                }
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(obj);
        }

        public async Task<IActionResult> Delete(int id)
        {
            Categories category = new();
            category = _db.Categories.FirstOrDefault(u => u.CategoryId == id);
            if (category == null)
            {
                return NotFound();
            }
            _db.Categories.Remove(category);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult CreateMultiple2() {
            List<Categories> categories = new List<Categories>();   
            for (int i = 0; i < 2; i++)
            {
                categories.Add(new Categories { CategoryName = Guid.NewGuid().ToString() });
            }
            _db.Categories.AddRange(categories);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        public IActionResult CreateMultiple5()
        {
            for (int i = 0; i < 4; i++)
            {
                _db.Categories.Add(new Categories { CategoryName = Guid.NewGuid().ToString() });
            }
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult RemoveMultiple2()
        {
            List<Categories> categories = 
                _db.Categories.OrderByDescending(u => u.CategoryId).Take(2).ToList();
            
            _db.Categories.RemoveRange(categories);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        public IActionResult RemoveMultiple5()
        {
            List<Categories> categories =
                _db.Categories.OrderByDescending(u => u.CategoryId).Take(5).ToList();

            _db.Categories.RemoveRange(categories);
            _db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

    }
}
