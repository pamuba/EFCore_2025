﻿using Microsoft.EntityFrameworkCore;
using EFCoreDemo_Model.Models;
using EFCroeDemo_DataAccess.FluentConfig;
using Microsoft.Extensions.Logging;
namespace EFCroeDemo_DataAccess.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Book> Books { get; set; }
        public DbSet<Genere> Generes { get; set; }
        public DbSet<Categories> Categories { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<SubCategory> SubCategories { get; set; }
        public DbSet<Publisher> Publishers { get; set; }
        public DbSet<BookDetail> BookDetails { get; set; }
        public DbSet<Fluent_BookDetail> BookDetails_fluent { get; set; }
        public DbSet<Fluent_Book> Fluent_Books { get; set; }
        public DbSet<Fluent_Publisher> Fluent_Publishers { get; set; }
        public DbSet<Fluent_Author> Fluent_Authors { get; set; }

        //rename table to Fluent_BookDetail

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options) { 
          
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //var serverVersion = new MySqlServerVersion(new Version(8, 0, 29));

            //base.OnConfiguring(optionsBuilder);
            //optionsBuilder.UseMySql(
            //    "server=127.0.0.1;uid=root;pwd=root@39;database=ecommerce2",
            //    serverVersion
            //    )
            //    .LogTo(Console.WriteLine, new[] { DbLoggerCategory.Database.Command.Name },
            //    LogLevel.Information);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new FluentAuthorConfig());
            modelBuilder.ApplyConfiguration(new FluentBookDetailConfig());
            modelBuilder.ApplyConfiguration(new FluentBookConfig());
            modelBuilder.ApplyConfiguration(new FluentPublisherConfig());
            modelBuilder.ApplyConfiguration(new FluentBookAuthorMapConfig());

            modelBuilder.Entity<Book>().Property(u => u.Price).HasPrecision(10, 5);
            modelBuilder.Entity<BookAuthorMap>().HasKey(u => new { u.Author_Id, u.BookId });

            //modelBuilder.Entity<Book>().HasData(
            //    new Book { BookId = 1, Title = "EF core", ISBN = "123456", Price = 10.11m, Publisher_Id=1 },
            //    new Book { BookId = 2, Title = ".Net core", ISBN = "343224", Price = 14.11m, Publisher_Id = 1 },
            //    new Book { BookId = 3, Title = "Web API core", ISBN = "123426", Price = 16.11m, Publisher_Id = 1 }
            //);
            //var bookList = new Book[]
            //{
            //     new Book {BookId=4 , Title="Web MVC core" , ISBN="125526", Price=17.11m,Publisher_Id=2}
            //};
            //modelBuilder.Entity<Book>().HasData(bookList);
        }
    }
}
