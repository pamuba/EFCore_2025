﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using EFCoreDemo_Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCroeDemo_DataAccess.FluentConfig
{
    public class FluentBookAuthorMapConfig : IEntityTypeConfiguration<Fluent_BookAuthorMap>
    {
        public void Configure(EntityTypeBuilder<Fluent_BookAuthorMap> modelBuilder)
        {
            modelBuilder.HasKey(u => new { u.Author_Id, u.BookId });
            modelBuilder
                .HasOne(z => z.Fluent_Book).WithMany(z => z.BookAuthorMap).HasForeignKey(z => z.BookId);
            modelBuilder
               .HasOne(z => z.Fluent_Author).WithMany(z => z.BookAuthorMap).HasForeignKey(z => z.Author_Id);
        }
    }
}
