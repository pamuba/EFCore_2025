﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreDemo_Model.Models
{
    [Table("tb_generes")]
    public class Genere
    {
        [Key]
        public int GenereId { get; set; }
        [Column("Name")]
        [Required]
        public string GenereName { get; set;}
        public int DisplayOrder { get; set; }

    }
}
