﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreDemo_Model.Models
{
    public class BookAuthorMap
    {
        [ForeignKey("Book")]
        [Key]
        public int BookId { get; set; }
        [ForeignKey("Author")]
        [Key]
        public int Author_Id { get; set; }

        public Book Book { get; set; }
        public Author Author { get; set; }

        //Can add more properties
    }
}
