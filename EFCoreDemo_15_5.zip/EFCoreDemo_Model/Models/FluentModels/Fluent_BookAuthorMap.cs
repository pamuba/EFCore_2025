﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreDemo_Model.Models
{
    public class Fluent_BookAuthorMap
    {
        //[ForeignKey("Book")]
        //[Key]
        public int BookId { get; set; }
        /// <summary>
        /// [ForeignKey("Author")]
        /// </summary>
        //[Key]
        public int Author_Id { get; set; }

        public Fluent_Author Fluent_Author { get; set; }
        public Fluent_Book Fluent_Book { get; set; }

        //public Fluent_Book Book { get; set; }
        //public Fluent_Author Author { get; set; }

        //Can add more properties
    }
}
