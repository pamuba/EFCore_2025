﻿using EFCoreDemo_Model.Models;
using EFCroeDemo_DataAccess.Data;
using Microsoft.EntityFrameworkCore;
internal class Program
{
    static void Main(string[] args)
    {
        //using (ApplicationDbContext context = new()) { 

        //    context.Database.EnsureCreated();
        //    if (context.Database.GetPendingMigrations().Count() > 0) { 
        //        context.Database.Migrate();
        //    }

            
        //    //AddBook(context);
        //    GetBook(context);
        //    //GetAllBooks(context);

        //}
    }
    static void GetBook(ApplicationDbContext context) {
        try {
            //var books = context.Books.OrderBy(u=>u.Title).OrderByDescending(u=>u.ISBN); 
            var books = context.Books.OrderBy(u => u.Title).ThenByDescending(u => u.ISBN);
            foreach (var book in books)
            {
                Console.WriteLine(book?.Title + "--" + book?.ISBN);
            }
            //var books = context.Books.Where(u => u.Publisher_Id == 2);
            //foreach (var book in books)
            //{
            //    Console.WriteLine(book?.Title + "--" + book?.ISBN);
            //}
            //var input = 20;

            //var book = context.Books.FirstOrDefault(u => u.Publisher_Id == 2 && u.Price > input);
            //var book = context.Books.Find(2);
            //Console.WriteLine(book?.Title + "--" + book?.ISBN);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    static void GetAllBooks(ApplicationDbContext context) { 
        var books = context.Books.ToList();
        foreach (var book in books)
        {
            Console.WriteLine(book.Title+"-"+book.ISBN);
        }
    }    
    static void AddBook(ApplicationDbContext context) {
        Book book = new() {Title="EFCroe", ISBN="4567", Price=2000m, Publisher_Id=1 };
        var books = context.Books.Add(book);
        context.SaveChanges();
    }
}